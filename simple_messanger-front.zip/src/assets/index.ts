import DarkMode from "./icons/DarkMode";
import LogOut from "./icons/LogOut";
import Search from "./icons/Search";
import Send from "./icons/Send";

export const Icons = {
    DarkMode,
    LogOut,
    Search,
    Send
};
