const login: string = "http://localhost:3000/auth/signIn";
const reg: string = "http://localhost:3000/auth/signUp";
const usersMessenges: string = "http://localhost:3000/ws/clients";

export const Links = {
    login,
    reg,
    usersMessenges,
};
