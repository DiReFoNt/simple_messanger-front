import { tokenAccess } from "./router/config";

const protocol = [];


export let socket = new WebSocket("ws://localhost:3000");

socket.onopen = function (e) {
    const message = JSON.stringify({
        type: "Authorization",
        data: `Bearer ${tokenAccess}`,
    });
    socket.send(message);
    console.log(e);
};
